
 var flag=0;
   function sleep(ms) {
      return new Promise(resolve => setTimeout(resolve, ms));
   }
async function goToActivityTab() {
    var activityTab=document.getElementsByClassName("artdeco-button artdeco-button--2 artdeco-button--secondary ember-view");
   for(var i=2;i<activityTab.length;i++){
      await sleep(5000);
       if(flag==1)
        break;
      activityTab[i].click();
       chrome.runtime.sendMessage({"message": "all"});
       
    }
}

//function call when page is injected
goToActivityTab();
//adding message listener on runtime
chrome.runtime.onMessage.addListener(
  function(request, sender, sendResponse) {
    if (request.msg === "stop"){
      flag=1;
   }
  }
);
