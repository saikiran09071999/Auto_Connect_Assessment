/* when user clicks the sto connect button this stopTheScript function is going 
  to be executed. These function sends an message to utility page to stop the 
  connection */
function stopTheScript(){
  document.getElementById('start').style.display="none";
  document.getElementById('stop').style.display="none"; 
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
  chrome.tabs.sendMessage(tabs[0].id, {msg: "stop"}, function(response) {
   });
}); 
}
function injectTheScript() {
  document.getElementById('start').style.display="none";
  document.getElementById('stop').style.display="inline"; 
    // Gets all tabs that have the specified properties, or all tabs if no properties are specified (in our case we choose current active tab)
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        // Injects JavaScript code into a page
        chrome.tabs.executeScript(tabs[0].id, {file: "utilities.js"});
    });
}
// adding listener to your button in popup window
document.getElementById('start').addEventListener('click', injectTheScript);
document.getElementById('stop').addEventListener('click', stopTheScript);
var count=0;
var mydeg=0;
// adding message listener for fetching requests sent from another page
chrome.runtime.onMessage.addListener(
 function(request, sender, sendResponse) {
   if( request.message === "all" ) {
     //getting request from utility page to update the no of connections in popup.html page
     count=count+1;
     mydeg=count*5;
     document.querySelector('.full').style.transform = "rotate("+mydeg+"deg)"; 
  document.querySelector('.fill').style.transform = "rotate("+mydeg+"deg)";
   document.querySelector('.inside-circle').innerHTML = count;
 
   }
  }
);

